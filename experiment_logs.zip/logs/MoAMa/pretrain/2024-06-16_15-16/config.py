GINConv = 'src.models.gnn.GINConv'
GNN = 'src.models.gnn.GNN'
LitMoAMa = 'src.models.moama.LitMoAMa'
MoAMa = 'src.models.moama.MoAMa'
batch_size = 256
ckpt_path = 'logs/MoAMa/pretrain/2024-06-13_23-13/checkpoints/epoch=14-step=117195.ckpt'
dataset = dict(
    dataset_path='dataset/zinc_standard_agent/processed/smiles.csv',
    masking_strategy=dict(
        mask_rate=0.15,
        motif_extractor=dict(
            motif_depth=5,
            type='src.featurizer.motif_extractor.MoMAMotifExtractor'),
        num_atom_type=119,
        type='src.featurizer.MotifMaskAtom'),
    type='src.data.datasets.zinc.Zinc')
dataset_path = 'dataset/zinc_standard_agent/processed/smiles.csv'
devices = [
    0,
]
emb_dim = 300
experiment_dir = 'logs/MoAMa/pretrain'
moama = dict(
    decoder=dict(
        aggr='add', emb_dim=300, out_dim=119, type='src.models.gnn.GINConv'),
    encoder=dict(
        drop_ratio=0.2, emb_dim=300, num_layer=5, type='src.models.gnn.GNN'),
    encoder_to_decoder=dict(
        args=[
            dict(type='torch.nn.PReLU'),
            dict(
                bias=False,
                in_features=300,
                out_features=300,
                type='torch.nn.Linear'),
        ],
        type='torch.nn.Sequential'),
    type='src.models.moama.MoAMa')
model = dict(
    beta=0.5,
    criterion='src.criterion.sce_loss',
    moama=dict(
        decoder=dict(
            aggr='add',
            emb_dim=300,
            out_dim=119,
            type='src.models.gnn.GINConv'),
        encoder=dict(
            drop_ratio=0.2,
            emb_dim=300,
            num_layer=5,
            type='src.models.gnn.GNN'),
        encoder_to_decoder=dict(
            args=[
                dict(type='torch.nn.PReLU'),
                dict(
                    bias=False,
                    in_features=300,
                    out_features=300,
                    type='torch.nn.Linear'),
            ],
            type='torch.nn.Sequential'),
        type='src.models.moama.MoAMa'),
    type='src.models.moama.LitMoAMa')
num_atom_type = 119
read_base = 'src.config.read_base'
sce_loss = 'src.criterion.sce_loss'
torch = 'torch.torch'
zinc_dataset = dict(
    dataset_path='dataset/zinc_standard_agent/processed/smiles.csv',
    masking_strategy=dict(
        mask_rate=0.15,
        motif_extractor=dict(
            motif_depth=5,
            type='src.featurizer.motif_extractor.MoMAMotifExtractor'),
        num_atom_type=119,
        type='src.featurizer.MotifMaskAtom'),
    type='src.data.datasets.zinc.Zinc')
