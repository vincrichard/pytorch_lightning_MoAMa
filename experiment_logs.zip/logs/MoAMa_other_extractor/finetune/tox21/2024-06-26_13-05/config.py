LitFinetune = 'src.models.finetuning_model.LitFinetune'
MeanAggregation = 'torch_geometric.nn.aggr.MeanAggregation'
batch_size = 32
dataset = dict(path='data/datasets/tox21.csv', type='src.data.datasets.Tox21')
devices = [
    0,
]
encoder = dict(
    drop_ratio=0.5, emb_dim=300, num_layer=5, type='src.models.gnn.GNN')
experiment_dir = 'logs/MoAMa_other_extractor/finetune/tox21'
model = dict(
    criterion=dict(type='torch.nn.BCEWithLogitsLoss'),
    encoder=dict(
        drop_ratio=0.5, emb_dim=300, num_layer=5, type='src.models.gnn.GNN'),
    pooling=dict(type='torch_geometric.nn.aggr.MeanAggregation'),
    prediction_head=dict(
        in_features=300, out_features=12, type='torch.nn.Linear'),
    type='src.models.finetuning_model.LitFinetune')
pretrained_model = dict(
    beta=0.5,
    criterion='src.criterion.sce_loss',
    moama=dict(
        decoder=dict(
            aggr='add',
            emb_dim=300,
            out_dim=119,
            type='src.models.gnn.GINConv'),
        encoder=dict(
            drop_ratio=0.2,
            emb_dim=300,
            num_layer=5,
            type='src.models.gnn.GNN'),
        encoder_to_decoder=dict(
            args=[
                dict(type='torch.nn.PReLU'),
                dict(
                    bias=False,
                    in_features=300,
                    out_features=300,
                    type='torch.nn.Linear'),
            ],
            type='torch.nn.Sequential'),
        type='src.models.moama.MoAMa'),
    type='src.models.moama.LitMoAMa')
pretrained_model_ckpt_path = 'logs/MoAMa_other_extractor/pretrain/2024-06-24_09-42/checkpoints/epoch=98-step=773487.ckpt'
read_base = 'src.config.read_base'
torch = 'torch.torch'
tox21_dataset = dict(
    path='data/datasets/tox21.csv', type='src.data.datasets.Tox21')
