BricsRingMotifExtractor = 'src.featurizer.motif_extractor.BricsRingMotifExtractor'
LitMoAMa = 'src.models.moama.LitMoAMa'
batch_size = 256
ckpt_path = None
dataset = dict(
    dataset_path='dataset/zinc_standard_agent/processed/smiles.csv',
    masking_strategy=dict(
        mask_rate=0.15,
        motif_extractor=dict(
            motif_depth=5,
            type='src.featurizer.motif_extractor.BricsRingMotifExtractor'),
        num_atom_type=119,
        type='src.featurizer.MotifMaskAtom'),
    type='src.data.datasets.zinc.Zinc')
dataset_path = 'dataset/zinc_standard_agent/processed/smiles.csv'
devices = [
    2,
]
experiment_dir = 'logs/MoAMa_other_extractor/pretrain'
moama = dict(
    decoder=dict(
        aggr='add', emb_dim=300, out_dim=119, type='src.models.gnn.GINConv'),
    encoder=dict(
        drop_ratio=0.2, emb_dim=300, num_layer=5, type='src.models.gnn.GNN'),
    encoder_to_decoder=dict(
        args=[
            dict(type='torch.nn.PReLU'),
            dict(
                bias=False,
                in_features=300,
                out_features=300,
                type='torch.nn.Linear'),
        ],
        type='torch.nn.Sequential'),
    type='src.models.moama.MoAMa')
model = dict(
    beta=0.5,
    criterion='src.criterion.sce_loss',
    moama=dict(
        decoder=dict(
            aggr='add',
            emb_dim=300,
            out_dim=119,
            type='src.models.gnn.GINConv'),
        encoder=dict(
            drop_ratio=0.2,
            emb_dim=300,
            num_layer=5,
            type='src.models.gnn.GNN'),
        encoder_to_decoder=dict(
            args=[
                dict(type='torch.nn.PReLU'),
                dict(
                    bias=False,
                    in_features=300,
                    out_features=300,
                    type='torch.nn.Linear'),
            ],
            type='torch.nn.Sequential'),
        type='src.models.moama.MoAMa'),
    type='src.models.moama.LitMoAMa')
read_base = 'src.config.read_base'
sce_loss = 'src.criterion.sce_loss'
zinc_dataset = dict(
    dataset_path='dataset/zinc_standard_agent/processed/smiles.csv',
    masking_strategy=dict(
        mask_rate=0.15,
        motif_extractor=dict(
            motif_depth=5,
            type='src.featurizer.motif_extractor.MoaMAMotifExtractor'),
        num_atom_type=119,
        type='src.featurizer.MotifMaskAtom'),
    type='src.data.datasets.zinc.Zinc')
