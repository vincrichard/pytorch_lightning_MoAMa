# I hard coded the weight loading to use the original paper weight here, so it does not appear in the configuration.
LitFinetune = "src.models.finetuning_model.LitFinetune"
MeanAggregation = "torch_geometric.nn.aggr.MeanAggregation"
batch_size = 32
dataset = dict(path="dataset/tox21/raw/tox21.csv", type="src.data.datasets.Tox21")
devices = [
    1,
]
encoder = dict(drop_ratio=0.5, emb_dim=300, num_layer=5, type="src.models.gnn.GNN")
experiment_dir = "logs/MoaMa_shared_weight/finetune/tox21"
model = dict(
    criterion=dict(type="torch.nn.BCEWithLogitsLoss"),
    encoder=dict(drop_ratio=0.5, emb_dim=300, num_layer=5, type="src.models.gnn.GNN"),
    pooling=dict(type="torch_geometric.nn.aggr.MeanAggregation"),
    prediction_head=dict(in_features=300, out_features=12, type="torch.nn.Linear"),
    type="src.models.finetuning_model.LitFinetune",
)
read_base = "src.config.read_base"
torch = "torch.torch"
tox21_dataset = dict(path="dataset/tox21/raw/tox21.csv", type="src.data.datasets.Tox21")
